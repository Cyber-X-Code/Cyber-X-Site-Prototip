robovox / created by Patrick H. Lauke aka redux / 27 Aug 2004 / http://www.splintered.co.uk
Designed for aliased font size of 6 pixels (or multiples thereof).
You may freely use this font for any commercial or non-commercial projects. A small credit and/or link to my site would be appreciated.